create function timestamptz(date, time without time zone) returns timestamp with time zone
STABLE
LANGUAGE SQL
AS $$
select cast(($1 + $2) as timestamp with time zone)
$$;
