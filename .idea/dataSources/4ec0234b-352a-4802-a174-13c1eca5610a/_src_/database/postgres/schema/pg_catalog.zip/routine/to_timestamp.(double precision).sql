create function to_timestamp(double precision) returns timestamp with time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select ('epoch'::pg_catalog.timestamptz + $1 * '1 second'::pg_catalog.interval)
$$;
